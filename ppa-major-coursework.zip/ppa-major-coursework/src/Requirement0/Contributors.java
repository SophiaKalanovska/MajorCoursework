
package Requirement0;


public class Contributors {

    public static void main(String[] args) {
        //creating main method to force change then commit
        
        System.out.println("Nathan Al Sibai");
        System.out.println("Sophia Kalanovska");
        System.out.println("Arthur Dantcikian");
        System.out.println("Kelvin van Vuuren");
    }
}
